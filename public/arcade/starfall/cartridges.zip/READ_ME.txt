STARFALL cartridge files
Open the STARFALL on-chain reader, then choose both .sfpart files.
They reconstruct the full game offline. Keep both files together.
The complete offline HTML game is also available from BMKR.
